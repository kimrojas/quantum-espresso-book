#!/bin/bash

rm -rf hb_h2_*.poscar