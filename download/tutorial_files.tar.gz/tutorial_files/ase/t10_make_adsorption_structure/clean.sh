#!/bin/bash

rm -rf run_files_*
rm -rf calc.*