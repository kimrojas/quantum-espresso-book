#!/bin/bash

rm -rf calc.* run.log
rm -rf run_files
rm -rf run_calc.log
rm -rf TMPDIR
rm -rf run_calc.dat
rm -rf plot.png
