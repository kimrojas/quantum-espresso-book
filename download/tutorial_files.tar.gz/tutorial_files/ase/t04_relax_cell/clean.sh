#!/bin/bash

rm -rf calc.*
rm -rf run_files
rm -rf run_calc.log
