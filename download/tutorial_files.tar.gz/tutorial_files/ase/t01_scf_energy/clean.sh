#!/bin/bash

rm -rf run_files* calc.* run.log