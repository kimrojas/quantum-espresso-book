#!/bin/bash

rm -rf run_files
rm -rf calc.*
