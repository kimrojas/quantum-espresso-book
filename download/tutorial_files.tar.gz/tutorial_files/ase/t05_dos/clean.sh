#!/bin/bash

rm -rf run_files* calc.* run_calc.log
rm -rf dosplot.png