#!/bin/bash

rm -rf run_files* calc.* run_calc.log