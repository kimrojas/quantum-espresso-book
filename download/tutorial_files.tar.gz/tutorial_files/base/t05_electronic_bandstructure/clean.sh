#!/bin/bash

rm -rf calc.* espresso_*.pwo projwfc.out run_calc.log TMPDIR
rm -rf pwscf.pdos*
rm -rf dosplot.png
rm -rf bands.out*
rm -rf espresso_bandx.out
rm -rf bandstructureplot.png