#!/bin/bash

rm -rf calc.* espresso.pwo run_calc.log TMPDIR