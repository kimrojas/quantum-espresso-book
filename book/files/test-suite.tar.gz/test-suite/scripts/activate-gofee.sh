#!/bin/bash

installdir=/home/krojas/tutorial_files/apps/gofee-master

export PYTHONPATH=${installdir}:$PYTHONPATH